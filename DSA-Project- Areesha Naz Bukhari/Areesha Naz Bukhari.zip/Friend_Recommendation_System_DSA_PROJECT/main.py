from models.user import User
from services.social_network import SocialNetwork
from services.recommendation_system import RecommendationSystem
from gui.main_gui import MainGUI
import tkinter as tk


def main():
    # Create the social network
    network = SocialNetwork()

    # Add users
    Areesha = User("1", "Areesha")
    Eisha = User("2", "Eisha")
    Mariyam = User("3", "Mariyam")
    Ibad = User("4", "Ibad")

    # Add interests
    Areesha.add_interest("Music")
    Areesha.add_interest("Cooking")

    Eisha.add_interest("Music")
    Eisha.add_interest("Sports")

    Mariyam.add_interest("Sports")
    Mariyam.add_interest("Gaming")

    Ibad.add_interest("Cooking")
    Ibad.add_interest("Music")

    # Add users to the network
    network.add_user(Areesha)
    network.add_user(Eisha)
    network.add_user(Mariyam)
    network.add_user(Ibad)

    # Add friendships
    network.add_friendship("1", "2")
    network.add_friendship("2", "3")
    network.add_friendship("3", "4")

    # Initialize the recommendation system
    recommender = RecommendationSystem()

    # Launch the GUI
    root = tk.Tk()
    MainGUI(root, network, recommender)
    root.mainloop()


if __name__ == "__main__":
    main()
