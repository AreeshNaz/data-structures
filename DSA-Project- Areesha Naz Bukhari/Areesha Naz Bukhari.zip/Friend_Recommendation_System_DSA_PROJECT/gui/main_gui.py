import tkinter as tk
from tkinter import ttk
from services.recommendation_system import RecommendationSystem


class MainGUI:
    def __init__(self, root, network, recommender):
        self.network = network
        self.recommender = recommender

        root.title("Friend Recommendation System")
        root.geometry("600x400")

        # Header Frame
        header_frame = tk.Frame(root)
        header_frame.pack(pady=10)

        tk.Label(header_frame, text="Select User:").pack(side=tk.LEFT)
        self.user_dropdown = ttk.Combobox(
            header_frame, values=[user.name for user in self.network.get_all_users()]
        )
        self.user_dropdown.pack(side=tk.LEFT)

        tk.Button(header_frame, text="Recommend by Mutual Friends", command=self.show_mutual_recommendations).pack(
            side=tk.LEFT, padx=5
        )
        tk.Button(header_frame, text="Recommend by Interests", command=self.show_interest_recommendations).pack(
            side=tk.LEFT
        )

        # Output Area
        self.output_area = tk.Text(root, height=15, width=70)
        self.output_area.pack(pady=10)

    def show_mutual_recommendations(self):
        user_name = self.user_dropdown.get()
        user = self.get_user_by_name(user_name)
        if user:
            recommendations = self.recommender.recommend_by_mutual_friends(user)
            formatted_recommendations = [f"{other_user.name} has {score} mutual friends with you!"
                                         for other_user, score in recommendations]
            self.display_recommendations("Mutual Friends", formatted_recommendations)

    def show_interest_recommendations(self):
        user_name = self.user_dropdown.get()
        user = self.get_user_by_name(user_name)
        if user:
            recommendations = self.recommender.recommend_by_interests(user, self.network)
            self.display_recommendations("Common Interests", recommendations)

    def display_recommendations(self, criteria, recommendations):
        self.output_area.delete(1.0, tk.END)
        self.output_area.insert(tk.END, f"Recommendations based on {criteria}:\n\n")
        if not recommendations:
            self.output_area.insert(tk.END, "No recommendations found.\n")
        else:
            for rec in recommendations:
                self.output_area.insert(tk.END, rec + "\n\n")  # Display full message

    def get_user_by_name(self, name):
        for user in self.network.get_all_users():
            if user.name == name:
                return user
        return None
