class User:
    def __init__(self, user_id, name):
        self.user_id = user_id
        self.name = name
        self.interests = set()
        self.friends = set()

    def add_interest(self, interest):
        self.interests.add(interest)

    def add_friend(self, friend):
        if isinstance(friend, User) and friend != self:
            self.friends.add(friend)

    def get_interests(self):
        return self.interests

    def get_friends(self):
        return self.friends

    def __repr__(self):
        return f"User({self.name}, ID: {self.user_id}, Interests: {self.interests})"
