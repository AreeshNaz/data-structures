from models.user import User

class SocialNetwork:
    def __init__(self):
        self.users = {}

    def add_user(self, user):
        self.users[user.user_id] = user

    def get_user(self, user_id):
        return self.users.get(user_id)

    def add_friendship(self, user_id1, user_id2):
        user1 = self.users.get(user_id1)
        user2 = self.users.get(user_id2)

        if user1 and user2:
            user1.add_friend(user2)
            user2.add_friend(user1)

    def get_all_users(self):
        return list(self.users.values())
