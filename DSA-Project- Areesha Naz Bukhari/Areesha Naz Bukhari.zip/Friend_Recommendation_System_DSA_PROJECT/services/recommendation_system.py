class RecommendationSystem:
    @staticmethod
    def recommend_by_mutual_friends(user):
        recommendations = {}
        for friend in user.get_friends():
            for friend_of_friend in friend.get_friends():
                if friend_of_friend != user and friend_of_friend not in user.get_friends():
                    recommendations[friend_of_friend] = recommendations.get(friend_of_friend, 0) + 1

        return sorted(recommendations.items(), key=lambda x: x[1], reverse=True)

    @staticmethod
    def recommend_by_interests(user, network):
        recommendations = []

        for other_user in network.get_all_users():
            if other_user == user or other_user in user.get_friends():
                continue

            common_interests = user.get_interests() & other_user.get_interests()

            if common_interests:
                message = f"{other_user.name} has similar interests like you ({', '.join(common_interests)}). " \
                          f"Connect with each other to get a better experience!"
                recommendations.append(message)

        return recommendations
